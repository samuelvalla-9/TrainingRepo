# 🏙 Metro Magnate

> A mobile-first Monopoly-style city property empire game with real-time online multiplayer (2–8 players).

---

## Architecture

```
metro-magnate/
├── client/          ← React + Vite frontend (deploys to Vercel)
│   └── src/
│       ├── App.jsx         ← Full game UI
│       ├── gameData.js     ← Board data (client copy)
│       └── index.css       ← Mobile-first styles
├── server/          ← Node.js WebSocket server
│   ├── server.js           ← WS room & message router
│   └── gameEngine.js       ← Full game logic
├── shared/
│   └── gameData.js         ← Shared board data (server uses this)
├── package.json     ← Server dependencies
└── vercel.json      ← Vercel build config
```

---

## Deployment Guide

### ⚠️ Important: Two Deployments Needed

Vercel hosts **serverless functions** only — it cannot run a persistent WebSocket server.
You need to deploy the **WebSocket server separately** (free options below), then deploy the **frontend to Vercel**.

---

### Step 1: Deploy the WebSocket Server

#### Option A: Railway (Recommended — free tier)

1. Go to [railway.app](https://railway.app) and sign up
2. Click **New Project → Deploy from GitHub repo**
3. Push your project to GitHub first, then connect it
4. Set the **root directory** to `/` (project root)
5. Set **start command**: `node server/server.js`
6. Railway will give you a URL like: `metro-magnate-production.up.railway.app`
7. Note this URL — you'll need it for the frontend env variable

#### Option B: Render (also free)

1. Go to [render.com](https://render.com) and sign up
2. New → Web Service → connect your GitHub repo
3. Build command: `npm install`
4. Start command: `node server/server.js`
5. Copy the provided URL

#### Option C: Run locally on your LAN

```bash
cd metro-magnate
npm install
npm start
# Server runs on port 8080
# Other devices on same WiFi connect using your local IP
# e.g. ws://192.168.1.42:8080
```

---

### Step 2: Deploy the Frontend to Vercel

1. Push the full project to GitHub

2. Go to [vercel.com](https://vercel.com) and import the repo

3. Set these build settings:
   - **Framework**: Other
   - **Build Command**: `cd client && npm install && npm run build`
   - **Output Directory**: `public`
   - **Install Command**: `npm install`

4. Add an **Environment Variable**:
   ```
   VITE_WS_URL = wss://your-railway-server.up.railway.app
   ```
   *(replace with your actual Railway/Render URL)*

5. Deploy! Vercel gives you a URL like `metro-magnate.vercel.app`

---

### Step 3: Play with Friends

Share your Vercel URL with friends anywhere in the world:
```
https://metro-magnate.vercel.app
```

- One player creates a room and shares the **5-letter room code**
- Others open the URL on their phone and enter the code
- Host taps **Start Game** when everyone is in
- Works over WiFi, mobile data, or any network ✅

---

## Local Development

```bash
# Terminal 1 — Start WebSocket server
cd metro-magnate
npm install
npm start        # Runs on ws://localhost:8080

# Terminal 2 — Start Vite dev server
cd metro-magnate/client
npm install
npm run dev      # Opens http://localhost:5173
```

The Vite dev server proxies `/ws` to localhost:8080 automatically.

---

## Game Features

| Feature | Details |
|---|---|
| Players | 2–8 simultaneous |
| Multiplayer | Real-time WebSocket, works across internet |
| Board | 40 spaces, 8 color groups, 4 railroads, 2 utilities |
| Properties | Buy, build houses (4) + hotels, mortgage/unmortgage |
| Cards | 14 Chance + 17 Community Chest cards (shuffled) |
| Trading | Cash + property trades between any two players |
| Auctions | Sealed-bid auction when player passes on buying |
| Jail | Roll doubles, use card, or pay $50 after 3 turns |
| Free Parking | Collects all tax/fine money as a pot |
| Bankruptcy | Auto-triggered or manual declaration |
| Reconnection | Players can rejoin by name if disconnected |

---

## Environment Variables

| Variable | Description | Example |
|---|---|---|
| `VITE_WS_URL` | WebSocket server URL (set in Vercel) | `wss://my-server.railway.app` |
| `PORT` | Server port (set automatically by Railway/Render) | `8080` |
