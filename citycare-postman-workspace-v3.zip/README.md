# CityCare Postman Workspace

## Files in this zip
- `CityCare.postman_collection.json` — All API endpoints organized by module
- `CityCare.postman_environment.json` — Environment variables (tokens, IDs)

---

## How to Import into Postman

1. Open Postman
2. Click **Import** (top left)
3. Drag both JSON files into the import window (or click "Upload Files" and select both)
4. Click **Import**
5. In the top-right corner, select **CityCare - Local** from the environment dropdown

---

## How JWT Tokens Work

Every Login request has a **Tests** script that automatically saves the JWT token to the environment variable.

| Login Request | Token Variable Saved |
|---|---|
| Login - Admin | `admin_token` |
| Login - Citizen (Ravi Kumar) | `citizen_token` |
| Login - Doctor (Dr. Anitha Sharma) | `doctor_token` |
| Login - Nurse (Priya Rajan) | `nurse_token` |
| Login - Dispatcher (Kumar Selvam) | `dispatcher_token` |
| Login - Compliance Officer (Meera Nair) | `compliance_token` |

Each folder uses the correct token automatically — no manual copying needed.

---

## Recommended Testing Order

```
1. 00 - Auth → Login as Admin        (saves admin_token)
2. 01 - Admin → Create Facility      (saves facility_id)
3. 01 - Admin → Add Ambulances       (saves ambulance_id)
4. 01 - Admin → Create Doctor/Nurse/Dispatcher/Compliance Officer
5. 00 - Auth → Register Citizen      (saves citizen_token)
6. 00 - Auth → Login as Citizen      (refreshes citizen_token)
7. 02 - Citizens → Create Profile    (saves citizen_id)
8. 02 - Citizens → Upload Documents  (saves document_id)
9. 00 - Auth → Login as Dispatcher   (saves dispatcher_token)
10. 03 - Emergencies → Report Emergency   (saves emergency_id)
11. 03 - Emergencies → View Pending (Dispatcher)
12. 03 - Emergencies → Dispatch Ambulance
13. 01 - Admin → Admit Patient       (saves patient_id)
14. 00 - Auth → Login as Doctor      (saves doctor_token)
15. 04 - Patients → Update Status
16. 05 - Treatments → Assign Treatment (saves treatment_id)
17. 05 - Treatments → Update Treatment Status
18. 00 - Auth → Login as Compliance  (saves compliance_token)
19. 06 - Compliance → Create Records, Schedule Audits
```

---

## Test Users Created

| Role | Email | Password |
|---|---|---|
| ADMIN | admin@citycare.com | admin123 |
| CITIZEN | ravi.kumar@citycare.com | ravi@123 |
| DOCTOR | anitha.sharma@citycare.com | doctor@123 |
| NURSE | priya.rajan@citycare.com | nurse@123 |
| DISPATCHER | kumar.selvam@citycare.com | dispatch@123 |
| COMPLIANCE_OFFICER | meera.nair@citycare.com | comply@123 |
| CITY_HEALTH_OFFICER | suresh.babu@citycare.com | health@123 |

---

## Base URL
`http://localhost:9090/api`

## Swagger UI
`http://localhost:9090/api/swagger-ui.html`
